Action()
{

	lr_start_transaction("Registration_03");

	lr_start_transaction("go_to_webtours");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"frame");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("sec-ch-ua", 
		"\"Not?A_Brand\";v=\"8\", \"Chromium\";v=\"108\", \"Google Chrome\";v=\"108\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/index.htm", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("go_to_webtours",LR_AUTO);

	lr_start_transaction("goto_registrationform");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(19);

	web_url("login.pl", 
		"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/home.html", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("goto_registrationform",LR_AUTO);

	lr_start_transaction("enter_userinfo");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(16);

	
	
	lr_save_string(lr_eval_string("{rndChar}{rndChar}{rndChar}{rndChar}{rndChar}{rndChar}"), "rndlogin");
	web_reg_find("TextPfx/IC=Thank you, <b>{rndlogin}",
		"TextSfx/IC=</b>, for registering and welcome to the Web Tours",
		LAST);
	
	web_submit_data("login.pl_2", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=info", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={rndlogin}", ENDITEM, 
		"Name=password", "Value={rndPassword}", ENDITEM, 
		"Name=passwordConfirm", "Value={rndPassword}", ENDITEM, 
		"Name=firstName", "Value={name}", ENDITEM, 
		"Name=lastName", "Value={surname}", ENDITEM, 
		"Name=address1", "Value={adress1}", ENDITEM, 
		"Name=address2", "Value={adress2}", ENDITEM, 
		"Name=register.x", "Value=61", ENDITEM, 
		"Name=register.y", "Value=10", ENDITEM, 
		LAST);

	lr_end_transaction("enter_userinfo",LR_AUTO);
	lr_start_transaction("next_page_after_registration");

	web_revert_auto_header("Sec-Fetch-User");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	lr_think_time(20);

	web_reg_find("Text/IC=User has returned to the home page.  Since user has already logged on",
		LAST);

	web_url("button_next.gif", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/login.pl", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("next_page_after_registration",LR_AUTO);

	lr_end_transaction("Registration_03",LR_AUTO);

	return 0;
}